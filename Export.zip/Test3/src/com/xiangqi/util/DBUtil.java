package com.xiangqi.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBUtil {
	private static String DB_DRIVER;

	private static String DB_URL;

	private static String DB_USER;

	private static String DB_PWD;

	/*
	String dbUrl = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=135.149.96.44)(PORT=1621)))(CONNECT_DATA=(SERVICE_NAME=tesdb)))";
	// theUserΪ���ݿ��û���
	String theUser = "sas";
	// thePwΪ���ݿ�����
	String thePw = "gs_fb_142";
	*/

	// �������ݿ����
	Connection c = null;
	Statement conn;
	ResultSet rs = null;

	static {
		InputStream in = null;
		try {
			Properties properties = new Properties();
			File configFile = new File("db.properties");
			if (configFile.exists()) {
				in = new FileInputStream(configFile);
			} else {
				in = ClassLoader.getSystemResourceAsStream("config/default.properties");
			}
			properties.load(in);
			DB_DRIVER = properties.getProperty("driver");
			DB_URL = properties.getProperty("url");
			DB_USER = properties.getProperty("username");
			DB_PWD = properties.getProperty("passworld");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public DBUtil() {
		// dbUrl="jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=135.149.96.44)(PORT=1621)))(CONNECT_DATA=(SERVICE_NAME=tesdb)))";
		try {
			Class.forName(DB_DRIVER).newInstance();
			// ��urlָ��������Դ��������
			c = DriverManager.getConnection(DB_URL, DB_USER, DB_PWD);
			// ����Statement���в�ѯ
			conn = c.createStatement();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ִ�в�ѯ
	public ResultSet executeQuery(String sql) {
		rs = null;
		try {
			rs = conn.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public void close() {
		try {
			conn.close();
			c.close();
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
