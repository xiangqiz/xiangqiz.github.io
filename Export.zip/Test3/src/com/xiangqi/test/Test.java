package com.xiangqi.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Test {

	public static void main(String[] args) throws IOException {
		File configFile = new File("db.properties");
		if (!configFile.exists()) {
			configFile = new File("src/config/default.properties");
		}
		System.out.println(configFile.getAbsolutePath() +"\t"+ configFile.exists());
		InputStream inputStream=ClassLoader.getSystemResourceAsStream("config/query.sql");
		InputStreamReader in=new InputStreamReader(inputStream);
		BufferedReader bufferedReader=new BufferedReader(in);
		System.out.println(bufferedReader.readLine());
	}
}
