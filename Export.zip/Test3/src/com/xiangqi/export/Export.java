package com.xiangqi.export;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.xiangqi.util.DBUtil;

public class Export {

	private static String resultFilePath = "result.xls";
	private static boolean showTitle = true;

	public static void main(String[] args) {
		Reader inputRead = null;
		String sqlFilePath = "";
		// ClassLoader.getSystemResource("config/query.sql").getPath();
		if (args.length > 0) {
			if (!"".equals(args[0])) {
				sqlFilePath = args[0];
				System.out.println("inputPath = " + sqlFilePath);
			}
			if (args.length > 1) {
				if (!"".equals(args[1])) {
					resultFilePath = args[1];
				}
			}
			if (args.length > 2) {
				showTitle = Boolean.parseBoolean(args[2]);
			}
		}
		String queryStr = "";
		if ("".equals(sqlFilePath)) {
			inputRead = new InputStreamReader(ClassLoader.getSystemResourceAsStream("config/query.sql"));
		} else {
			File sqlFile = new File(sqlFilePath);
			if (sqlFile.exists()) {
				try {
					inputRead = new FileReader(sqlFile);
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			} else {
				System.out.println("�ļ�" + sqlFile.getAbsolutePath() + "�����ڣ�");
				return;
			}
		}
		Export export = new Export();
		queryStr = export.readStringFromReader(inputRead);
		export.queryDateAndCreateFile(queryStr);
	}

	private String readStringFromReader(Reader reader) {
		StringBuilder sb = new StringBuilder();
		BufferedReader bufferedReader = new BufferedReader(reader);
		String string = null;
		try {
			while ((string = bufferedReader.readLine()) != null) {
				sb.append(string);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	private void queryDateAndCreateFile(String sql) {
		System.out.println("SQL>>> " + sql);
		// ����һ��������
		HSSFWorkbook workbook = new HSSFWorkbook();
		// ����һ������
		HSSFSheet sheet = workbook.createSheet("Sheel1");

		DBUtil util = new DBUtil();
		ResultSet rs = util.executeQuery(sql);
		try {
			ResultSetMetaData rsmd = rs.getMetaData();

			int count = rsmd.getColumnCount();
			int index = 0;

			if (showTitle) {
				HSSFRow row = sheet.createRow(index++);
				for (short i = 0; i < count; i++) {
					HSSFCell cell = row.createCell(i);
					cell.setCellType(HSSFCell.CELL_TYPE_STRING);

					HSSFRichTextString richString = new HSSFRichTextString(rsmd.getColumnLabel(i + 1));
					cell.setCellValue(richString);
				}
			}

			while (rs.next()) {
				HSSFRow row = sheet.createRow(index++);

				for (short i = 0; i < count; i++) {
					HSSFCell cell = row.createCell(i);
					cell.setCellType(HSSFCell.CELL_TYPE_STRING);

					HSSFRichTextString richString = new HSSFRichTextString(rs.getString(i + 1));
					cell.setCellValue(richString);
				}
			}
			File resultFile = new File(resultFilePath);
			File parentFile = resultFile.getParentFile();
			if (null != parentFile && !parentFile.exists()) {
				System.out.println("�ϼ�Ŀ¼������,���Զ�����");
				parentFile.mkdirs();
			}
			System.out.println("outPath = " + resultFilePath);
			workbook.write(new FileOutputStream(resultFile));
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			util.close();
		}
	}

}
